﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class DoUong
    {
        private String ma;
        private String ten;
        private double giaBan;
        public String Ma { get => ma; set => ma=value; }
        public String Ten { get => ten; set => ten=value; }
        public double GiaBan { get => giaBan; set => giaBan=value; }
        public DoUong() { }
        public DoUong(String ma, String ten, double giaBan)
        {
            this.ma=ma;
            this.ten=ten;
            this.giaBan=giaBan;
        }
        //Xuat thong tin do uong
        public String Export()
        {
            return "\nTen do uong: " + this.Ten + "\nGia ban: " + this.GiaBan.ToString();
        }
        //Nhap thong tin do uong
        //public void Import()
        //{
        //    Console.Write("\nNhap ma do uong: ");
        //    String tempMa = Console.ReadLine();
        //    Console.Write("Nhap ten do uong: ");
        //    String tempTen = Console.ReadLine();
        //    Console.Write("Nhap gia: ");
        //    double tempGia = Convert.ToDouble(Console.ReadLine());
        //    this.Ma = tempMa;
        //    this.Ten = tempTen;
        //    this.GiaBan = tempGia;
        //}
    }
}
