﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Nhom22_Detai2
{
    public class Program
    {
        static void Main(string[] args)
        {   
            Console.WriteLine("[QUAN LY TRA SUA]\n");
            ConsoleMenu.ShowMenu();
        }
    }
}
