﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    internal class QuanLyDuLieu
    {
        public static List<DoUong> listMenu = new List<DoUong>();
        public static List<NguyenLieu> listNguyenLieu = new List<NguyenLieu>();
        public static List<KhachHang> listKhachHang = new List<KhachHang>();
        public static List<KhachHangVip> listKhachHangVip = new List<KhachHangVip>();
        public static List<NhanVien> listNhanVien = new List<NhanVien>();
        static QuanLyDuLieu()
        {
            CultureInfo cultures = new CultureInfo("en-US");
            DoUong new1 = new DoUong("1", "Tra sua truyen thong", 25000);
            DoUong new2 = new DoUong("2", "Tra sua tran chau duong den", 40000);
            DoUong new3 = new DoUong("3", "Tra sua suong sao", 50000);
            DoUong new4 = new DoUong("4", "Tra sua Olong", 50000);
            DoUong new5 = new DoUong("5", "Tra sua trai cay", 45000);
            DoUong new6 = new DoUong("6", "Tra dao hoang gia chai 2 lit", 150000);
            DoUong new7 = new DoUong("7", "Tra chanh pha yen sao dam dac nguyen chat", 120000);
            DoUong new8 = new DoUong("8", "Tra tac pha ruou tao", 80000);
            listMenu.Add(new1);
            listMenu.Add(new2);
            listMenu.Add(new3);
            listMenu.Add(new4);
            listMenu.Add(new5);
            listMenu.Add(new6);
            listMenu.Add(new7);
            listMenu.Add(new8);

            NguyenLieu no1 = new NguyenLieu("Tran chau", 18000, 35);
            NguyenLieu no2 = new NguyenLieu("Sua tuoi", 15000, 40);
            NguyenLieu no3 = new NguyenLieu("Bot suong sao", 25000, 40);
            NguyenLieu no4 = new NguyenLieu("Bot duong den", 16000, 50);
            NguyenLieu no5 = new NguyenLieu("Tra Olong", 10000, 30);
            NguyenLieu no6 = new NguyenLieu("Tra", 8000, 40);
            NguyenLieu no7 = new NguyenLieu("Trai cay tuoi", 10000, 20);
            listNguyenLieu.Add(no1);
            listNguyenLieu.Add(no2);
            listNguyenLieu.Add(no3);
            listNguyenLieu.Add(no4);
            listNguyenLieu.Add(no5);
            listNguyenLieu.Add(no6);
            listNguyenLieu.Add(no7);

            KhachHang kh1 = new KhachHang("1", "A", DateTime.Parse("11/11/2003", cultures), "2158821867", "20 Le Vu", 4);
            KhachHang kh2 = new KhachHang("2", "B", DateTime.Parse("02/09/2000", cultures), "6413513241", "102 Nguyen Van Troi", 1);
            KhachHang kh3 = new KhachHang("3", "C", DateTime.Parse("12/18/1999", cultures), "2231512515", "1106 Khong Minh", 8);
            listKhachHang.Add(kh1);
            listKhachHang.Add(kh2);
            listKhachHang.Add(kh3);

            KhachHangVip kh_vip1 = new KhachHangVip("VIP1", "VA", DateTime.Parse("09/09/1996", cultures), "521848848", "199 Le Dinh Chinh", 23);
            KhachHangVip kh_vip2 = new KhachHangVip("VIP2", "VB", DateTime.Parse("07/08/2001", cultures), "613512341", "12 Gia Cat Luong", 14);
            KhachHangVip kh_vip3 = new KhachHangVip("VIP3", "VC", DateTime.Parse("10/29/2004", cultures), "132414311", "46 Quang Trung", 32);
            KhachHangVip kh_vip4 = new KhachHangVip("VIP4", "VD", DateTime.Parse("01/06/1993", cultures), "663422213", "201 Le Quy Don", 55);
            listKhachHangVip.Add(kh_vip1);
            listKhachHangVip.Add(kh_vip2);
            listKhachHangVip.Add(kh_vip3);
            listKhachHangVip.Add(kh_vip4);

            NhanVien nv1 = new NhanVien("NV1", "N1", DateTime.Parse("11/18/2000", cultures), "217576126", "232123213213", "21 Le Van Luyen", 27);
            NhanVien nv2 = new NhanVien("NV2", "N2", DateTime.Parse("10/09/1993", cultures), "412321314", "123122142144", "774 Le Ha", 27);
            NhanVien nv3 = new NhanVien("NV3", "N3", DateTime.Parse("08/14/1998", cultures), "857283991", "757821399400", "884 Nguyen Trai", 25);
            NhanVien nv4 = new NhanVien("NV4", "N4", DateTime.Parse("03/18/1996", cultures), "912342134", "958219300041", "06 Nguyen Hue", 26);
            listNhanVien.Add(nv1);
            listNhanVien.Add(nv2);
            listNhanVien.Add(nv3);
            listNhanVien.Add(nv4);
        }   
    }
}
