﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class NhanVien
    {
        private String maNV;
        private String ten;
        private DateTime ngaysinh;
        private String sdt;
        private String cmnd;
        private String diachi;
        private int soNgayLamViec;    //1 thang
        private long luong;

        public String MaNV { get => this.maNV; set => this.maNV=value; }
        public String Ten { get => ten; set => ten=value; }
        public DateTime Ngaysinh { get => ngaysinh; set => ngaysinh=value; }
        public String Sdt { get => sdt; set => sdt=value; }
        public String Cmnd { get => cmnd; set => cmnd=value; }
        public String Diachi { get => diachi; set => diachi=value; }
        public int SoNgayLamViec { get => soNgayLamViec; set => soNgayLamViec=value; }
        public long Luong { get => luong; set => luong=value; }

        public NhanVien() { }
        public NhanVien(String maNV, String ten, DateTime ngaysinh, String sdt, String cmnd, String diachi, int soNgayLamViec)
        {
            this.maNV=maNV;
            this.ten=ten;
            this.ngaysinh=ngaysinh;
            this.sdt=sdt;
            this.cmnd=cmnd;
            this.diachi=diachi;
            this.soNgayLamViec=soNgayLamViec;
            this.luong=this.ChamCong();
        }
        //Dang ky nhan vien moi
        public void dangKyNV()
        {
            Console.WriteLine("[Dang ky nhan vien]");
            Console.Write("Nhap ma NV: ");
            String tempMaNV = Console.ReadLine();
            Console.Write("Nhap ten: ");
            String tempTen = Console.ReadLine();
            Console.Write("Nhap ngay sinh(mm/dd/yyyy): ");
            CultureInfo cultures = new CultureInfo("en-US");
            String ngaysinh = Console.ReadLine();
            DateTime tempNgaySinh = DateTime.Parse(ngaysinh, cultures);
            Console.Write("Nhap SDT: ");
            String tempSDT = Console.ReadLine();
            Console.Write("Nhap CMND: ");
            String tempCMND = Console.ReadLine();
            Console.Write("Nhap dia chi: ");
            String tempDiaChi = Console.ReadLine();
            this.MaNV = tempMaNV;
            this.Ten = tempTen;
            this.Ngaysinh = tempNgaySinh;
            this.Sdt = tempSDT;
            this.Cmnd = tempCMND;
            this.Diachi = tempDiaChi;
            this.SoNgayLamViec = 27;
        }
        public long ChamCong()
        {
            long l = 0;
            int y = DateTime.Now.Year;
            int m = DateTime.Now.Month;
            int thisMonth = DateTime.DaysInMonth(y, m); //So ngay trong thang nay`
            l = 3000000-(thisMonth-4-this.SoNgayLamViec)*100000;   //Luong co ban 3m, thang duoc nghi 4 ngay, vang 1 ngay ko phep tru 200k
            return l;
        }
        //Xuat thong tin nhan vien
        public virtual String Export()
        {
            return "\nMa NV: " + this.MaNV + "\nHo ten: " + this.ten + "\nNgay sinh: " + this.Ngaysinh.ToString() + "\nSDT: " + this.Sdt + "\nCMND: " + this.Cmnd + "\nDia chi: " + this.Diachi + "\nLuong thang nay: " + this.ChamCong().ToString();
        }
    }
}
