﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;

namespace Nhom22_Detai2
{
    public class Menu
    {
        private List<DoUong> drinks;

        public List<DoUong> Drinks { get => drinks; set => drinks=value; }

        public Menu() { }
        public Menu(List <DoUong> drinks)
        {
            this.drinks = drinks;
        }
        public void XuatMenu()
        {
            Console.WriteLine("[Menu]\n");
            foreach (DoUong i in this.drinks)
                Console.WriteLine(i.Ma + ". " + i.Ten + " ___________________________ " + i.GiaBan.ToString() + "\n");
        }
        public List <DoUong> MuaHang(List <String> maDoUong)
        {
            List <DoUong> drinksBought = new List<DoUong>();
            foreach (String i in maDoUong)
            {
                foreach (DoUong j in this.drinks)
                if (i.Equals(j.Ma))
                {
                    drinksBought.Add(j);
                }
            }
            return drinksBought;
        }
    }
}
