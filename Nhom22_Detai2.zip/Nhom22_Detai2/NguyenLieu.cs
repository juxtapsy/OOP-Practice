﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class NguyenLieu
    {
        private String ten;
        private double gia;
        private int soLuong;
        private double tong;

        public string Ten { get => ten; set => ten=value; }
        public double Gia { get => gia; set => gia=value; }
        public int SoLuong { get => soLuong; set => soLuong=value; }
        public double Tong { get => tong; set => tong=value; }

        public NguyenLieu() { }
        public NguyenLieu(String ten, double gia, int soLuong)
        {
            this.ten=ten;
            this.gia=gia;
            this.soLuong=soLuong;
            this.tong=this.TinhTong();
        }
        //Tinh tong chi phi
        double TinhTong()
        {
            double sum = 0.0;
            sum = sum + this.Gia * this.SoLuong;
            return sum;
        }
        //Xuat thong tin nguyen lieu
        public String Export()
        {
            return "Ten nguyen lieu: " + this.Ten + "\nDon gia: " + this.Gia.ToString() + "\nSo luong: " + this.SoLuong + "\nTong: " + this.Tong;
        }
    }
}
