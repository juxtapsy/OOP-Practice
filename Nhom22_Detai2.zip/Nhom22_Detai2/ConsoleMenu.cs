﻿using Nhom22_Detai2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class ConsoleMenu
    {
        public static void ShowMenu()
        {
            Menu menu = new Menu(QuanLyDuLieu.listMenu);
            menu.XuatMenu();
            List<NguyenLieu> listNguyenLieu = QuanLyDuLieu.listNguyenLieu;
            List<KhachHang> listKhachHang = QuanLyDuLieu.listKhachHang;
            List<KhachHangVip> listKhachHangVip = QuanLyDuLieu.listKhachHangVip;
            List<NhanVien> listNhanVien = QuanLyDuLieu.listNhanVien;
            List<String> listDanhGia = new List<String>();
            double tongThu = 0.0;

            while (true)
            {
                Console.WriteLine("\n1. Khach hang\n2. Nhan vien\n3. Nguyen lieu\n4. Doanh thu\n5. Thoat");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        XuatMenuKhachHang();
                        break;
                    case 2:
                        XuatMenuNhanVien();
                        break;
                    case 3:
                        XuatMenuNguyenLieu();
                        break;
                    case 4:
                        XuatMenuDoanhThu();
                        break;
                    case 5:
                        System.Environment.Exit(0);
                        break;
                }
            }

            void XuatMenuKhachHang()
            {
                Console.WriteLine("\n1. Dang ky KH moi\n2. Dang ky KH vip\n3. Xuat thong tin KH\n4. Mua hang\n5. Danh gia");
                int choiceKH = Convert.ToInt32(Console.ReadLine());
                if (choiceKH == 1)
                {
                    KhachHang khMoi = new KhachHang();
                    khMoi.DangKyKH();
                    listKhachHang.Add(khMoi);
                }
                if (choiceKH == 2)
                {
                    KhachHangVip khVip = new KhachHangVip();
                    khVip.DangKyKH();
                    listKhachHangVip.Add(khVip);
                }
                if (choiceKH == 3)
                {
                    Console.WriteLine("1. Xuat thong tin 1 khach hang\n2. Xuat thong tin tat ca khach hang");
                    int choiceKHXuatThongTin = Convert.ToInt32(Console.ReadLine());
                    XuatSubMenuKhachHang3(choiceKHXuatThongTin);
                }
                if (choiceKH == 4)
                {
                    Console.WriteLine("\n1. Mua Offline\n2. Mua Online");
                    int choiceKHMuaHang = Convert.ToInt32(Console.ReadLine());
                    XuatSubMenuKhachHang4(choiceKHMuaHang);
                }
                if (choiceKH == 5)
                {
                    Console.WriteLine("Ban co danh gia/gop y gi danh cho cua hang? ");
                    String danhGia = Console.ReadLine();
                    listDanhGia.Add(danhGia);
                    Console.WriteLine("Cam on y kien cua ban.");
                }
            }

            void XuatSubMenuKhachHang3(int choiceKHXuatThongTin)
            {
                if (choiceKHXuatThongTin == 1)
                {
                    Console.Write("Nhap ma KH: ");
                    String tempMaKH = Console.ReadLine();
                    foreach (KhachHang i in listKhachHang)
                    {
                        if (tempMaKH.Equals(i.MaKH))
                        {
                            Console.WriteLine("[Thong tin khach hang]");
                            Console.WriteLine(i.Export());
                        }
                    }
                    foreach (KhachHangVip j in listKhachHangVip)
                    {
                        if (tempMaKH.Equals(j.MaKH))
                        {
                            Console.WriteLine("[Thong tin khach hang]");
                            Console.WriteLine(j.Export());
                        }
                    }
                }
                if (choiceKHXuatThongTin == 2)
                {
                    foreach (KhachHang i in listKhachHang)
                        Console.WriteLine(i.Export());
                    foreach (KhachHangVip j in listKhachHangVip)
                        Console.WriteLine(j.Export());
                }
            }

            void KhachQuaDuongMuaHang(List <DoUong> drinksBought)
            {
                KhachHang khachQuaDuong = new KhachHang();
                DateTime now = DateTime.Now;
                HoaDon hoaDon = new HoaDon(khachQuaDuong, now, drinksBought);
                hoaDon.XuatHoaDon();
                tongThu += hoaDon.Tong;
            }

            void KhachQuenMuaHang(List <DoUong> drinksBought)
            {
                Console.Write("Nhap ma KH: ");
                String tempMaKH = Console.ReadLine();
                foreach (KhachHang i in listKhachHang)
                {
                    if (i.MaKH.Equals(tempMaKH))
                    {
                        DateTime now = DateTime.Now;
                        HoaDon hoaDon = new HoaDon(i, now, drinksBought);
                        hoaDon.XuatHoaDon();
                        tongThu += hoaDon.Tong;
                    }
                }
                foreach (KhachHangVip j in listKhachHangVip)
                {
                    if (j.MaKH.Equals(tempMaKH))
                    {
                        DateTime now = DateTime.Now;
                        HoaDonVip hoaDonVip = new HoaDonVip(j, now, drinksBought);
                        hoaDonVip.XuatHoaDon();
                        tongThu += hoaDonVip.Tong;
                    }
                }
            }

            void KhachQuenMuaHangOnline(List <DoUong> drinksBoughtOnl)
            {
                Console.Write("Nhap ma KH: ");
                String tempMaKH = Console.ReadLine();
                foreach (KhachHang i in listKhachHang)
                {
                    if (i.MaKH.Equals(tempMaKH))
                    {
                        DateTime now = DateTime.Now;
                        HoaDon hoaDon = new HoaDon(i, now, drinksBoughtOnl);
                        hoaDon.XuatHoaDon();
                        tongThu += hoaDon.Tong;
                        ShipKhachQuen(i);
                    }
                }
                foreach (KhachHangVip j in listKhachHangVip)
                {
                    if (j.MaKH.Equals(tempMaKH))
                    {
                        DateTime today = DateTime.Today;
                        HoaDonVip hoaDonVip = new HoaDonVip(j, today, drinksBoughtOnl);
                        hoaDonVip.XuatHoaDon();
                        tongThu += hoaDonVip.Tong;
                        ShipKhachQuenVip(j);
                    }
                }
            }

            void ShipKhachQuen(KhachHang i)
            {
                Console.WriteLine("1. Ship toi dia chi ban nhap tren he thong\n2. Ship toi dia chi khac");
                int choiceShip = Convert.ToInt32(Console.ReadLine());
                if (choiceShip == 1)
                    Console.WriteLine("Dia chi ship: " + i.Diachi);
                if (choiceShip == 2)
                {
                    Console.Write("Nhap dia chi muon ship: ");
                    String tempDiaChi = Console.ReadLine();
                    Console.WriteLine("Dia chi ship: " + tempDiaChi);
                }
            }

            void ShipKhachQuenVip(KhachHangVip j)
            {
                Console.WriteLine("1. Ship toi dia chi ban nhap tren he thong\n2. Ship toi dia chi khac");
                int choiceShip = Convert.ToInt32(Console.ReadLine());
                if (choiceShip == 1)
                    Console.WriteLine("Dia chi ship: " + j.Diachi);
                if (choiceShip == 2)
                {
                    Console.Write("Nhap dia chi muon ship: ");
                    String tempDiaChi = Console.ReadLine();
                    Console.WriteLine("Dia chi ship: " + tempDiaChi);
                }
            }

            void XuatSubMenuKhachHang4(int choiceKHMuaHang)
            {
                if (choiceKHMuaHang == 1)
                {
                    Console.Write("Nhap so luong do uong muon mua: ");
                    int soLuong = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Nhap ma do uong muon mua: ");
                    List<String> listMaDoUong = new List<String>();
                    for (int i = 0; i < soLuong; i++)
                    {
                        String tempMaDoUong = Console.ReadLine();
                        listMaDoUong.Add(tempMaDoUong);
                    }
                    List<DoUong> drinksBought = menu.MuaHang(listMaDoUong);
                    Console.WriteLine("Do uong da chon: ");
                    foreach (DoUong drink in drinksBought)
                        Console.WriteLine(drink.Export());
                    Console.WriteLine("\n1. Khach qua duong\n2. Khach quen");
                    int typeKH = Convert.ToInt32(Console.ReadLine());
                    if (typeKH == 1)
                        KhachQuaDuongMuaHang(drinksBought);
                    if (typeKH == 2)
                        KhachQuenMuaHang(drinksBought);
                }

                if (choiceKHMuaHang == 2)
                {
                    Console.Write("Nhap so luong do uong muon mua: ");
                    int soLuongOnl = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Nhap ma do uong muon mua: ");
                    List<String> listMaDoUongOnl = new List<String>();
                    for (int i = 0; i < soLuongOnl; i++)
                    {
                        String tempMaDoUongOnl = Console.ReadLine();
                        listMaDoUongOnl.Add(tempMaDoUongOnl);
                    }
                    List<DoUong> drinksBoughtOnl = menu.MuaHang(listMaDoUongOnl);
                    Console.WriteLine("Do uong da chon: ");
                    foreach (DoUong drink in drinksBoughtOnl)
                        Console.WriteLine(drink.Export());
                    Console.WriteLine("\n1. Khach qua duong\n2. Khach quen");
                    int typeKHOnl = Convert.ToInt32(Console.ReadLine());
                    if (typeKHOnl == 1)
                    {
                        KhachQuaDuongMuaHang(drinksBoughtOnl);
                        Console.Write("Nhap dia chi muon ship: ");
                        String tempDiaChi = Console.ReadLine();
                        Console.WriteLine("Dia chi ship: " + tempDiaChi);
                    }
                    if (typeKHOnl == 2)
                        KhachQuenMuaHangOnline(drinksBoughtOnl);   
                }
            }

            void XuatMenuNhanVien()
            {
                Console.WriteLine("\n1. Dang ky nhan vien moi\n2. Xuat thong tin\n3. Xoa thong tin\n4. Gop y");
                int choiceNV = Convert.ToInt32(Console.ReadLine());
                if (choiceNV == 1)
                {
                    NhanVien nvMoi = new NhanVien();
                    nvMoi.dangKyNV();
                    listNhanVien.Add(nvMoi);
                }
                if (choiceNV == 2)
                {
                    Console.WriteLine("\n1. Xuat thong tin 1 nhan vien\n2. Xuat thong tin tat ca nhan vien");
                    int choiceXuatNV = Convert.ToInt32(Console.ReadLine());
                    XuatSubMenuNhanVien2(choiceXuatNV);
                }
                if (choiceNV == 3)
                {
                    Console.Write("Nhap ma NV: ");
                    String tempMaNV = Console.ReadLine();
                    foreach (NhanVien i in listNhanVien)
                        if (i.MaNV.Equals(tempMaNV))
                            listNhanVien.Remove(i);
                }
                if (choiceNV == 4)
                {
                    Console.WriteLine("Nhan vien co gop y gi danh cho cua hang?");
                    String nvGopY = Console.ReadLine();
                    listDanhGia.Add(nvGopY);
                    Console.WriteLine("Cam on gop y cua ban. Cua hang truong se xem xet.");
                }
            }

            void XuatSubMenuNhanVien2(int choiceXuatNV)
            {
                if (choiceXuatNV == 1)
                {
                    Console.Write("Nhap ma NV: ");
                    String tempMaNV = Console.ReadLine();
                    foreach (NhanVien i in listNhanVien)
                        if (i.MaNV.Equals(tempMaNV))
                            Console.WriteLine(i.Export());
                }
                if (choiceXuatNV == 2)
                    foreach (NhanVien j in listNhanVien)
                        Console.WriteLine(j.Export());
            }

            void XuatMenuNguyenLieu()
            {
                Console.WriteLine("[Nguyen lieu]");
                foreach (NguyenLieu i in listNguyenLieu)
                    Console.WriteLine(i.Export());
            }

            void XuatMenuDoanhThu()
            {
                Console.WriteLine("[Doanh thu]");
                DoanhThu doanhThu = new DoanhThu(tongThu);
                Console.WriteLine(doanhThu.Export());
            }
        }
    }
}

