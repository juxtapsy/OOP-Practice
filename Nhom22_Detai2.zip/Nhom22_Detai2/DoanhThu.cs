﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class DoanhThu
    {   //Thu, chi, loi nhuan trong 1 thang
        private double thu;
        public static double chi = DoanhThu.TinhTongChi();  //Gia? su? khoan? chi la` co^' dinh.
        private double loiNhuan;
        public double Thu { get => thu; set => thu=value; }
        public double LoiNhuan { get => loiNhuan; set => loiNhuan=value; }

        public DoanhThu() { }
        public DoanhThu(double thu)
        {
            this.Thu=thu;
            this.loiNhuan=this.TinhLoiNhuan();
        }

        public static double TinhTongChi()
        {
            double tempChi = 0.0;
            List<NguyenLieu> listNguyenLieu = QuanLyDuLieu.listNguyenLieu;
            List<NhanVien> listNhanVien = QuanLyDuLieu.listNhanVien;
            foreach (NguyenLieu i in listNguyenLieu)
                tempChi += i.Tong;
            foreach (NhanVien j in listNhanVien)
                tempChi += Convert.ToDouble(j.Luong);
            return tempChi;
        }
        public double TinhLoiNhuan()
        {
            double ln = this.Thu - DoanhThu.chi;
            return ln;
        }
        public String Export()
        {
            return "\nThu: " + this.Thu.ToString() + "\nChi: " + DoanhThu.chi.ToString() + "\nLoi nhuan: " + this.LoiNhuan;
        }
    }
}
