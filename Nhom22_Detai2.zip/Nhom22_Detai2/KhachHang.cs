﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class KhachHang
    {
        private String maKH;
        private String ten;
        private String sdt;
        private String diachi;
        private DateTime ngaysinh;
        private int tichdiem;

        public String MaKH { get => maKH; set => maKH=value; }
        public String Ten { get => ten; set => ten=value; }
        public String Sdt { get => sdt; set => sdt=value; }
        public String Diachi { get => diachi; set => diachi=value; }
        public DateTime Ngaysinh { get => ngaysinh; set => ngaysinh=value; }
        public int Tichdiem { get => tichdiem; set => tichdiem=value; }

        public KhachHang() { }
        public KhachHang(String maKH, String ten, DateTime ngaysinh, String sdt, String diachi, int tichdiem)
        {
            this.maKH=maKH;
            this.ten=ten;
            this.ngaysinh=ngaysinh;
            this.sdt=sdt;
            this.diachi=diachi;
            this.tichdiem=tichdiem;
        }
        //Xuat thong tin khach hang
        public virtual String Export()
        {
            return "\nMa KH: " + this.MaKH + "\nHo ten: " + this.Ten +"\nNgay sinh: " + this.Ngaysinh.ToString() + "\nSDT: " + this.Sdt + "\nDia chi: " + this.Diachi + "\nDiem tich luy: " + this.Tichdiem.ToString();
        }
        public virtual void DangKyKH()
        {
            Console.WriteLine("[Dang ky khach hang moi]\n");
            Console.Write("Nhap ma KH: ");
            String tempMaKH = Console.ReadLine();
            Console.Write("Nhap ten: ");
            String tempTen = Console.ReadLine();
            Console.Write("Nhap ngay sinh (mm/dd/yyyy): ");
            CultureInfo cultures = new CultureInfo("en-US");
            String ngaysinh = Console.ReadLine();
            DateTime tempNgaySinh = DateTime.Parse(ngaysinh, cultures);
            Console.Write("Nhap SDT: ");
            String tempSDT = Console.ReadLine();
            Console.Write("Nhap dia chi: ");
            String tempDiaChi = Console.ReadLine();
            this.MaKH = tempMaKH;
            this.Ten = tempTen;
            this.Ngaysinh = tempNgaySinh;
            this.Sdt = tempSDT;
            this.Diachi = tempDiaChi;
            this.Tichdiem = 0;
        }
    }
    public class KhachHangVip : KhachHang
    {
        private String capBac;
        //10 diem: Dong         20 diem: Bac           50 diem: Vang
        // Dong: giam 5% gia tri hoa don, duoc tang 1 ly tra sua truyen thong
        // Bac: giam 10% gia tri hoa don, duoc chon 1 ly nuoc bat ky gia < 20000
        // Vang: giam 15% gia tri hoa don, duoc chon 1 ly nuoc bat ky hang` thang'
        private double uuDai;

        public String CapBac { get => capBac; set => capBac=value; }
        public double UuDai { get => uuDai; set => uuDai=value; }
        public KhachHangVip() { }
        public KhachHangVip(String maKH, String ten, DateTime ngaysinh, String sdt, String diachi, int tichdiem)
        {
            this.MaKH = maKH;
            this.Ten = ten;
            this.Ngaysinh = ngaysinh;
            this.Sdt = sdt;
            this.Diachi = diachi;
            this.Tichdiem = tichdiem;
            this.CapBac = this.XetCapBac();
            this.UuDai = this.TinhMucUuDai(); 
        }
        public String XetCapBac()
        {
            int temp = this.Tichdiem;
            if (temp >= 10 && temp < 20)
                return "Dong";
            else if (temp >= 20 && temp < 50)
                return "Bac"; 
            else
                return "Vang";  
        }
        public double TinhMucUuDai()
        {
            String temp = this.XetCapBac();
            if (temp.Equals("Dong"))
                return 0.95;
            else if (temp.Equals("Bac"))
                return 0.9;
            else
                return 0.85;
        }
        public override void DangKyKH()
        {
            base.DangKyKH();
            Console.Write("Nhap diem tich luy: ");
            int tempDiem = Convert.ToInt32(Console.ReadLine());
            this.Tichdiem = tempDiem;
            this.CapBac = this.XetCapBac();
            this.UuDai = this.TinhMucUuDai();
        }
        public override String Export()
        {
            return base.Export() + "\nCap bac: " + this.CapBac;
        }
    }
}
