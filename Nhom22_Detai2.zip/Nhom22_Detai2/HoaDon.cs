﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Nhom22_Detai2
{
    public class HoaDon
    {
        private KhachHang khachHang;
        private DateTime date;
        private List<DoUong> drinksBought;
        private double tong;

        public KhachHang KhachHang { get => khachHang; set => khachHang=value; }
        public DateTime Date { get => date; set => date=value; }
        public List<DoUong> DrinksBought { get { return drinksBought; } set { drinksBought = value; } }       
        public double Tong { get => tong; set => tong=value; }

        public HoaDon() { }
        public HoaDon(KhachHang khachHang, DateTime date, List<DoUong> drinksBought)
        {
            this.khachHang=khachHang;
            this.date=date;
            this.drinksBought = drinksBought;
            this.tong=this.TinhTong();
        }          

        public virtual double TinhTong()
        {
            double sum = 0;
            int len = this.drinksBought.Count();
            foreach (DoUong i in drinksBought)
                sum += i.GiaBan;
            return sum;
        }
        public virtual void XuatHoaDon()
        {
            Console.WriteLine("[Hoa don]");
            Console.WriteLine("Ngay mua: " + this.date.ToString());
            Console.WriteLine("Do uong da mua: ");
            foreach (DoUong i in drinksBought)
                Console.WriteLine(i.Export());
            Console.WriteLine("\nTong: " + this.TinhTong());
        }
    }
    public class HoaDonVip : HoaDon {
        private KhachHangVip khVip;

        public KhachHangVip KhVip { get => khVip; set => khVip=value; }

        public HoaDonVip() { }
        public HoaDonVip(KhachHangVip khVip, DateTime date, List<DoUong> drinksBought)
        {
            this.KhVip = khVip;
            this.Date = date;
            this.DrinksBought = drinksBought;
            this.Tong = this.TinhTong();
        }

        public override double TinhTong()
        {
            return base.TinhTong()*this.KhVip.TinhMucUuDai();
        }
        public override void XuatHoaDon()
        {
            base.XuatHoaDon();
            double uuDai = (1.0 - this.KhVip.TinhMucUuDai())*100.0;
            Console.WriteLine("Uu dai: " + uuDai.ToString() + "%");
        }
    }
}
